<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Karyawan_model');
        $this->load->model('Order_model');
    }

    public function index()
	{
        $data['karyawan']= $this->Karyawan_model->getdata();
		$this->load->view('karyawan/profil', $data);
	}

    public function update_karyawan($id_karyawan) 
    {
        $data['dataedit'] = $this->Karyawan_model->getdatabyid($id_karyawan);
        $this->load->view('karyawan/edit_karyawan', $data);
    }

    public function editdata()
    {
        $id_karyawan = $this->input->post('id_karyawan');
        $nama_karyawan = $this->input->post('nama_karyawan');
        $username = $this->input->post('username');
        $alamat_karyawan = $this->input->post('alamat_karyawan');
        $alamat_cabang = $this->input->post('alamat_cabang');
        $email = $this->input->post('email');
        $no_telepon = $this->input->post('no_telepon');
        $status   = $this->input->post('status');
        $foto_karyawan      = $_FILES['foto_karyawan']['name'];

            if($foto_karyawan)
            {
                $config ['upload_path']         = './assets/foto/foto_karyawan/';
                $config ['allowed_types']       = 'jpg|jpeg|png|tiff';

                $this->load->library('upload', $config);
                
                if($this->upload->do_upload('foto_karyawan'))
                {
                    $foto_karyawan=$this->upload->data('file_name');
                    $this->db->set('foto_karyawan', $foto_karyawan);
                }
                else
                {
                    echo $this->upload->display_errors();
                }
            }
        
    
        $data = array(
            'nama_karyawan' => $nama_karyawan,
            'alamat_karyawan' => $alamat_karyawan,
            'email' => $email,
            'alamat_cabang' => $alamat_cabang,
            'no_telepon' => $no_telepon,
            'username' => $username,
            'status' => $status,
             
        );
        
        $kondisi = array(
            'id_karyawan' => $id_karyawan,
        );

        $update = $this->Karyawan_model->update($data, $kondisi);
        if($update){
            redirect('karyawan/profil','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }
}

?>