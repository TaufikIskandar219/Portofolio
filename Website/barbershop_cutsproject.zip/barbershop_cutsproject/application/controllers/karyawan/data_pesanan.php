<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_pesanan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
        $this->load->model('Karyawan_model');
		$this->load->model('Order_model');
	}
	public function index()
    {
        $karyawan = $this->session->userdata('id_karyawan');
    	$data['pesanan'] = $this->db->query("SELECT * FROM pesanan ps, pelanggan pl, karyawan ky,
         Layanan ly WHERE ps.id_pelanggan=pl.id_pelanggan AND ps.id_karyawan=ky.id_karyawan AND 
         ps.id_layanan=ly.id_layanan AND ky.id_karyawan=$karyawan ORDER BY id_pesanan DESC")->result();
        
        $this->load->view('karyawan/data_pesanan',$data);
        
    } 

	public function getedit($id_pesanan) 
    {
        $data['dataedit'] = $this->Order_model->getdatabyid($id_pesanan);
        $this->load->view('karyawan/edit_pesanan', $data);
    }

    public function editdata()
    {
        $id_pesanan = $this->input->post('id_pesanan');
        $status_pesanan   = $this->input->post('status_pesanan');
		$status_pembayaran   = $this->input->post('status_pembayaran');
        $keterangan = $this->input->post('keterangan');

        $data = array(
            'status_pesanan' => $status_pesanan,
			'status_pembayaran' => $status_pembayaran,
            'keterangan' => $keterangan,
        );
        
        $kondisi = array(
            'id_pesanan' => $id_pesanan,
        );

        $update = $this->Order_model->update($data, $kondisi);
        if($update){
            redirect('karyawan/data_pesanan','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }
}

?>