<?php
class pendapatan extends CI_Controller
{
    public function __construct()
	{
		parent::__construct();
        $this->load->model('Karyawan_model');
		$this->load->model('Order_model');
	}
    public function index()
    {
        $dari = $this->input->post('dari');
        $sampai = $this->input->post('sampai');
        $karyawan = $this->session->userdata('id_karyawan');
        $this->_rules();
        $data['pendapatan'] = $this->db->query("SELECT * FROM pesanan ps, karyawan ky, layanan ly, pelanggan pl WHERE ps.id_karyawan=ky.id_karyawan AND ps.id_pelanggan=pl.id_pelanggan AND ps.id_layanan=ly.id_layanan AND ps.status_pesanan='Selesai' AND date(tanggal_pesanan) >= '$dari' AND date(tanggal_pesanan) <= '$sampai' AND ky.id_karyawan=$karyawan")->result();
        $this->load->view('karyawan/pendapatan', $data);
    }
    public function _rules()
    {
        $this->form_validation->set_rules('dari','Dari Tanggal','required',array('required' => 'Tanggal Dari Wajib Diisi'));
        $this->form_validation->set_rules('sampai','Sampai Tanggal','required',array('required' => 'Tanggal Sampai Wajib Diisi'));
    }
}
?>
