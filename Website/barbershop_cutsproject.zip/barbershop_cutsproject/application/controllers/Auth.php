<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Auth_model');
    }

    public function login()
    {

        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
   
        $cek = $this->Auth_model->cek_login_pelanggan($email, $password);
        if($cek == FALSE) {
            $cek2 = $this->Auth_model->cek_login_karyawan($email, $password);
            if($cek2 == FALSE ) {
                $cek3 = $this->Auth_model->cek_login_admin($email, $password);
                if($cek3 == FALSE ) {
                    $this->session->set_flashdata('pesan','<div class="alert alert-danger
                alert-dismissible fade show" role="alert">
                    Email Atau Password Salah !
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>');

                redirect('welcome/login');
                }else{
                    $this->session->set_userdata('id_admin',$cek3->id_admin);
                    $this->session->set_userdata('nama_admin',$cek3->nama_admin);
                    $this->session->set_userdata('alamat_admin',$cek3->alamat_admin);
                    $this->session->set_userdata('email',$cek3->email);
                    $this->session->set_userdata('no_telepon',$cek3->no_telepon);
                    $this->session->set_userdata('username',$cek3->username);
                    $this->session->set_userdata('password',$cek3->password);
                    $this->session->set_userdata('foto_admin',$cek3->foto_admin);

                    redirect('admin/dashboard');
                }

            }else{
                $this->session->set_userdata('id_karyawan',$cek2->id_karyawan);
                $this->session->set_userdata('nama_karyawan',$cek2->nama_karyawan);
                $this->session->set_userdata('alamat_karyawan',$cek2->alamat_karyawan);
                $this->session->set_userdata('email',$cek2->email);
                $this->session->set_userdata('no_telepon',$cek2->no_telepon);
                $this->session->set_userdata('username',$cek2->username);
                $this->session->set_userdata('password',$cek2->password);
                $this->session->set_userdata('foto_karyawan',$cek2->foto_karyawan);
                $this->session->set_userdata('status',$cek2->status);
                $this->session->set_userdata('status_pembayaran',$cek2->status_pembayaran);

                redirect('karyawan/dashboard');
            }
    
        }else{
            $this->session->set_userdata('id_pelanggan',$cek->id_pelanggan);
            $this->session->set_userdata('nama_pelanggan',$cek->nama_pelanggan);
            $this->session->set_userdata('alamat',$cek->alamat);
            $this->session->set_userdata('email',$cek->email);
            $this->session->set_userdata('password',$cek->password);

            redirect('pelanggan/dashboard');
        }
        
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('welcome');
    }

}

?>