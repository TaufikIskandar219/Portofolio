<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Layanan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Layanan_model');
    }

    public function index()
    {
        $data['layanan'] = $this->Layanan_model->getdata();
        $this->load->view('admin/data_layanan', $data);
    }
    public function ftambah()
    {
        $data = array(
            'title' => "form tambah"
        );
        $this->load->view('admin/tambah_layanan', $data);
    }

    public function tambah()
    {
        $id_layanan    = $this->input->post('id_layanan');
        $nama_layanan  = $this->input->post('nama_layanan');
        $ket_layanan   = $this->input->post('ket_layanan');
        $tarif         = $this->input->post('tarif');
        $foto_layanan  = $_FILES['foto_layanan'];
        if ($foto_layanan = '') {
        } else {
            $config['upload_path']      = './assets/foto/foto_layanan/';
            $config['allowed_types']    = 'gif|jpg|png';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('foto_layanan')) {
                echo "Upload Gagal";
                die();
            } else {
                $foto_layanan = $this->upload->data('file_name');
            }
        }

        $data = array(
            'id_layanan' => $id_layanan,
            'nama_layanan' => $nama_layanan,
            'ket_layanan' => $ket_layanan,
            'tarif' => $tarif,
            'foto_layanan' => $foto_layanan,
        );
        $save = $this->Layanan_model->save($data);
        if ($save) {
            redirect('admin/layanan', 'refresh');
        } else {
            echo 'Data gagal disimpan!!';
        }
    }

    public function getedit($id_layanan)
    {
        $data['dataedit'] = $this->Layanan_model->getdatabyid($id_layanan);
        $this->load->view('admin/edit_layanan', $data);
    }

    public function editdata()
    {
        $id_layanan    = $this->input->post('id_layanan');
        $nama_layanan  = $this->input->post('nama_layanan');
        $ket_layanan   = $this->input->post('ket_layanan');
        $tarif         = $this->input->post('tarif');

        $data = array(
            'id_layanan' => $id_layanan,
            'nama_layanan' => $nama_layanan,
            'ket_layanan' => $ket_layanan,
            'tarif' => $tarif,
        );
        $kondisi = array(
            'id_layanan' => $id_layanan,
        );

        $update = $this->Layanan_model->update($data, $kondisi);
        if ($update) {
            redirect('admin/layanan', 'refresh');
        } else {
            echo 'Data gagal Disimpan';
        }
    }

    function hapus($id_layanan)
    {
        $gambar = new Layanan_model;

        if ($gambar->checkProductImage($id_layanan)) {
            $data = $gambar->checkProductImage($id_layanan);
            if (file_exists("./assets/foto/foto_layanan/" .$data->foto_layanan)) {
                unlink("./assets/foto/foto_layanan/" .$data->foto_layanan);
            }

            $kondisi = array(
                'id_layanan' => $id_layanan,
            );

            $delete = $this->Layanan_model->delete($kondisi);
            $this->session->set_flashdata('status', 'Data berhasil di hapus');
            if ($delete) {
                redirect('admin/layanan', 'refresh');
            } else {
                echo 'Data gagal Disimpan';
            }
        }
    }
}
?>