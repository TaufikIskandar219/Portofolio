<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pelanggan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pelanggan_model');
    }

    public function index()
    {
        $data['pelanggan'] = $this->Pelanggan_model->getdata();
        $this->load->view('admin/data_pelanggan', $data);
    }
    public function ftambah()
    {
        $data = array(
            'title' => "form tambah"
        );
        $this->load->view('admin/tambah_pelanggan', $data);
    }

    public function tambah()
    {
        $id_pelanggan    = $this->input->post('id_pelanggan');
        $email = $this->input->post('email');
        $password   = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $nama_pelanggan = $this->input->post('nama_pelanggan');
    
        $data = array(
            'id_pelanggan' => $id_pelanggan,
            'email' => $email,
            'password' => $password,
            'no_telepon' => $no_telepon,
            'nama_pelanggan' => $nama_pelanggan,
        );
        $save = $this->Pelanggan_model->save($data);
        if ($save) {
            redirect('admin/Pelanggan', 'refresh');
        } else {
            echo 'Data gagal disimpan!!';
        }
    }

    public function getedit($id_pelanggan)
    {
        $data['dataedit'] = $this->Pelanggan_model->getdatabyid($id_pelanggan);
        $this->load->view('admin/edit_pelanggan', $data);
    }

    public function editdata()
    {
        $id_pelanggan = $this->input->post('id_pelanggan');
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $nama_pelanggan = $this->input->post('nama_pelanggan');

        $data = array(
            'email' => $email,
            'no_telepon' => $no_telepon,
            'password' => $password,
            'nama_pelanggan' => $nama_pelanggan,
        );
        $kondisi = array(
            'id_pelanggan' => $id_pelanggan,
        );

        $update = $this->Pelanggan_model->update($data, $kondisi);
        if ($update) {
            redirect('admin/pelanggan', 'refresh');
        } else {
            echo 'Data gagal Disimpan';
        }
    }

    function hapus($id_pelanggan)
    {
        $gambar = new Pelanggan_model;

        if ($gambar->checkProductImage($id_pelanggan)) {
            $data = $gambar->checkProductImage($id_pelanggan);
            if (file_exists("./assets/foto/foto_pelanggan/" . $data->foto_pelanggan)) {
                unlink("./assets/foto/foto_pelanggan/" .$data->foto_pelanggan);
            }

            $kondisi = array(
                'id_pelanggan' => $id_pelanggan,
            );

            $delete = $this->Pelanggan_model->delete($kondisi);
            $this->session->set_flashdata('status', 'Data berhasil di hapus');
            if ($delete) {
                redirect('admin/Pelanggan', 'refresh');
            } else {
                echo 'Data gagal Disimpan';
            }
        }
    }
}
