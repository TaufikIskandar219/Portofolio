<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class laporan extends CI_Controller {
	
	public function index()
	{	
		$data['judul'] = 'Laporan';
		$this->load->view('admin/data_laporan', $data);
	}
	
}

 ?>