<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class penggajian extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->model('Penggajian_model');
    }
	
	public function index()
		{
			$dari = $this->input->post('dari');
			$sampai = $this->input->post('sampai');
			$id_karyawan = $this->input->post('id_karyawan');
			$this->_rules();

		if($this->form_validation->run() == FALSE) {
        $data['karyawan'] = $this->Penggajian_model->get_data('karyawan')->result();
        $this->load->view('admin/filter_penggajian',$data);
		}else{
			$data['laporan'] = $this->db->query("SELECT * FROM pesanan ps, karyawan ky, layanan ly, pelanggan pl 
			WHERE ps.status_pesanan = 'Selesai' AND ps.id_karyawan=ky.id_karyawan AND 
			ps.id_pelanggan=pl.id_pelanggan AND ps.id_layanan=ly.id_layanan  
			AND ps.id_karyawan='$id_karyawan' AND date(tanggal_pesanan) >= '$dari' AND date(tanggal_pesanan)
			 <= '$sampai'")->result();
        $this->load->view('admin/tampilkan_penggajian',$data);
		}

		}

		public function _rules()
		{
			$this->form_validation->set_rules('dari','Dari tanggal','required');
			$this->form_validation->set_rules('sampai','Sampai tanggal','required');
		}
}

 ?>