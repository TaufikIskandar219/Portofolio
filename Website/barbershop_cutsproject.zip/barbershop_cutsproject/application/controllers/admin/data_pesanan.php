<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_pesanan extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
        $this->load->model('Karyawan_model');
		$this->load->model('Order_model');
	}
	
	public function index()
    {
        $data['pesanan'] = $this->Order_model->pesanan_masuk('pesanan')->result();
        $this->load->view('admin/data_pesanan',$data);
    } 

    public function selesai()
    {
        $data['pesanan'] = $this->Order_model->pesanan_selesai('pesanan')->result();
        $this->load->view('admin/pesanan_selesai',$data);
    } 
    public function getedit($id_pesanan) 
    {
        $data['dataedit'] = $this->Order_model->getdatabyid($id_pesanan);
        $this->load->view('admin/edit_pesanan_masuk', $data);
    }

    public function editdata()
    {
        $id_pesanan = $this->input->post('id_pesanan');
        $status_pesanan   = $this->input->post('status_pesanan');
		$status_pembayaran   = $this->input->post('status_pembayaran');

        $data = array(
            'status_pesanan' => $status_pesanan,
			'status_pembayaran' => $status_pembayaran,
        );
        
        $kondisi = array(
            'id_pesanan' => $id_pesanan,
        );

        $update = $this->Order_model->update($data, $kondisi);
        if($update){
            redirect('admin/data_pesanan','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }
    public function laporan()
    {
        $data['pesanan'] = $this->Order_model->pesanan_selesai('pesanan')->result();
        $this->load->view('admin/laporan',$data);
    } 
	
}

 ?>