<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class pesanan_selesai extends CI_Controller {
	
	public function index()
	{	
		$data['judul'] = 'Pesanan Selesai';
		$this->load->view('admin/data_pesanan_selesai', $data);
	}
	
}

 ?>