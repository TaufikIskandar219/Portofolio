<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Barbershop extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barbershop_model');
    }
    public function index()
    {
        $data = array(
            'title' => "Form Tambah"
        );
        $this->load->view('admin/tambah_barbershop', $data);
    }
    public function barbershop()
    {
        $data['barbershop'] = $this->Barbershop_model->getdata();
        $this->load->view('admin/data_barbershop', $data);
    }

    public function ftambah()
    {
        $data = array(
            'title' => "Form Tambah"
        );
        $this->load->view('admin/tambah_barbershop', $data);
    }

    public function tambah()
    {
        $id_barbershop = $this->input->post('id_barbershop');
        $alamat_barbershop = $this->input->post('alamat_barbershop');
        $deskripsi = $this->input->post('deskripsi');
        $no_wa = $this->input->post('no_wa');

        $data = array(
            'id_barbershop' => $id_barbershop,
            'alamat_barbershop' => $alamat_barbershop,
            'deskripsi' => $deskripsi,
            'no_wa' => $no_wa,
        );

        $save = $this->Barbershop_model->save($data);
        if ($save) {
            redirect('admin/barbershop/barbershop', 'refresh');
        } else {
            echo 'Data gagal Disimpan';
        }
    }

    public function getedit($id_barbershop)
    {
        $data['dataedit'] = $this->Barbershop_model->getdatabyid($id_barbershop);
        $this->load->view('admin/edit_barbershop', $data);
    }

    public function editdata()
    {
        $id_barbershop = $this->input->post('id_barbershop');
        $alamat_barbershop = $this->input->post('alamat_barbershop');
        $deskripsi = $this->input->post('deskripsi');
        $no_wa = $this->input->post('no_wa');

        $data = array(

            'alamat_barbershop' => $alamat_barbershop,
            'deskripsi' => $deskripsi,
            'no_wa' => $no_wa,
        );

        $kondisi = array(
            'id_barbershop' => $id_barbershop,
        );

        $update = $this->Barbershop_model->update($data, $kondisi);
        if ($update) {
            redirect('admin/barbershop/barbershop', 'refresh');
        } else {
            echo 'Data gagal Disimpan';
        }
    }

    function hapus($id_barbershop)
    {
        $kondisi = array(
            'id_barbershop' => $id_barbershop,
        );
        
        $delete = $this->Barbershop_model->delete($kondisi); 
        $this->session->set_flashdata('status', 'Data berhasil di hapus');
        if ($delete) {
            redirect('admin/barbershop/barbershop', 'refresh');
        } else {
            echo 'Data gagal Dihapus';
        }


    }
}