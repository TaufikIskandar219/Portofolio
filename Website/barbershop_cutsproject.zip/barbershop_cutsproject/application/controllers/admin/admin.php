<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model');
        $this->load->model('Penggajian_model');
	}
	public function index() {
        $data['admin'] = $this->Admin_model->getdata();
        $data['count'] = $this->Penggajian_model->get_all_count();
        $this->load->view('admin/dashboard', $data);
      }
	public function admin()
	{
		$data['admin'] = $this->Admin_model->getdata();
		$this->load->view('admin/data_admin', $data);
	}

    public function ftambah() {
        $data = array(
          'title' => "Form Tambah"
        );
        $this->load->view('admin/tambah_admin', $data);
      }

	public function tambah()
    {
        $id_admin = $this->input->post('id_admin');
        $nama_admin = $this->input->post('nama_admin');
        $username = $this->input->post('username');
        $alamat_admin = $this->input->post('alamat_admin');
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $foto_admin = $_FILES['foto_admin'];
        if ($foto_admin=''){}else{
            $config['upload_path']      = './assets/foto/foto_admin/';
            $config['allowed_types']    = 'gif|jpg|png';
            $config['max_size']        = 1048;

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('foto_admin')){
                echo "Upload Gagal"; die();
            }else{
                $foto_admin= $this->upload->data('file_name');
            }
        }

        $data = array(
            'id_admin' => $id_admin,
            'nama_admin' => $nama_admin,
            'username' => $username,
            'alamat_admin' => $alamat_admin,
            'email' => $email,
            'password' => $password,
            'no_telepon' => $no_telepon,
            'foto_admin' => $foto_admin,
        );

        $save = $this->Admin_model->save($data);
        if($save){
            redirect('admin/admin/admin','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }

    public function getedit($id_admin) 
    {
        $data['dataedit'] = $this->Admin_model->getdatabyid($id_admin);
        $this->load->view('admin/edit_admin', $data);
    }

    public function editdata()
    {
        $id_admin = $this->input->post('id_admin');
        $nama_admin = $this->input->post('nama_admin');
        $username = $this->input->post('username');
        $alamat_admin = $this->input->post('alamat_admin');
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $foto_admin      = $_FILES['foto_admin']['name'];

        if($foto_admin )
        {
            $config ['upload_path']         = './assets/foto/foto_admin/';
            $config ['allowed_types']       = 'jpg|jpeg|png|tiff';

            $this->load->library('upload', $config);
            
            if($this->upload->do_upload('foto_admin'))
            {
                $foto_admin=$this->upload->data('file_name');
                $this->db->set('foto_admin', $foto_admin );
            }
            else
            {
                echo $this->upload->display_errors();
            }
        }

        $data = array(
            'nama_admin' => $nama_admin,
            'alamat_admin' => $alamat_admin,
            'email' => $email,
            'no_telepon' => $no_telepon,
            'username' => $username,
            'password' => $password,
            
        );
        $kondisi = array(
            'id_admin' => $id_admin,
        );

        $update = $this->Admin_model->update($data, $kondisi);
        if($update){
            redirect('admin/admin/admin','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }

    function hapus($id_admin)
    {
        $gambar = new Admin_model; //membuat objek dari class model admin_model

        if($gambar->checkProductImage($id_admin)){ //Kondisi pengecekan Gambar
            $data = $gambar->checkProductImage($id_admin); // Pengambilan data gambar
            // $data->foto_admin; >>>>  Pengambilan data nama gambar sesuai id yang dipilih
            if (file_exists("./assets/foto/".$data->foto_admin)) {
                unlink("./assets/foto/".$data->foto_admin); //fungsi unlink untuk menghapus gambar yang tersimpan di local
            }

            $kondisi = array(
                'id_admin' => $id_admin,
            );
    
            $delete = $this->Admin_model->delete($kondisi); //untuk menghapus data yang ada di tabel admin
            $this->session->set_flashdata('status','Data berhasil di hapus');            
            if($delete){
                redirect('admin/admin/admin','refresh');
            }else{
                echo 'Data gagal Dihapus';
            }
           
        }
    }
}

?>