<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Admin_model');
		$this->load->model('Penggajian_model');
	}
	public function index() {
        $data['admin'] = $this->Admin_model->getdata();
		$data['count'] = $this->Penggajian_model->get_all_count();
        $this->load->view('admin/dashboard', $data);
    }
}

?>
	