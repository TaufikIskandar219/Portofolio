<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Karyawan_model');
    }

    public function index()
    {
        $data = array(
            'title' => "Dashboard"
        );
        $this->load->view('karyawan/dashboard', $data);
    }

	public function karyawan()
	{
        $data['karyawan']= $this->Karyawan_model->getdata();
		$this->load->view('admin/data_karyawan', $data);
	}
    public function ftambah()
    {
        $data = array(
            'title' => "form tambah"
        );
        $this->load->view('admin/tambah_karyawan', $data);
    }

    public function tambah()
    {
        $id_karyawan    = $this->input->post('id_karyawan');
        $nama_karyawan  = $this->input->post('nama_karyawan');
        $username       = $this->input->post('username');
        $alamat_karyawan = $this->input->post('alamat_karyawan');
        $alamat_cabang = $this->input->post('alamat_cabang');
        $email = $this->input->post('email');
        $password   = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $status   = $this->input->post('status');
        $foto_karyawan = $_FILES['foto_karyawan'];
        if ($foto_karyawan=''){}else{
            $config['upload_path']      = './assets/foto/foto_karyawan';
            $config['allowed_types']    = 'gif|jpg|png';

            $this->load->library('upload', $config);
            if(!$this->upload->do_upload('foto_karyawan')){
                echo "Upload Gagal"; die();
            }else{
                $foto_karyawan= $this->upload->data('file_name');
            }
        }

        $data = array(
            'id_karyawan' => $id_karyawan,
            'nama_karyawan' => $nama_karyawan,
            'username' => $username,
            'alamat_karyawan' => $alamat_karyawan,
            'alamat_cabang' => $alamat_cabang,
            'email' => $email,
            'password' => $password,
            'no_telepon' => $no_telepon,
            'status' => $status,
            'foto_karyawan' => $foto_karyawan, 
        );
        $save = $this->Karyawan_model->save($data);
        if($save){
            redirect('admin/karyawan/karyawan','refresh');
        }else{
            echo 'Data gagal disimpan!!';
        }
    }
    
    public function getedit($id_karyawan) 
    {
        $data['dataedit'] = $this->Karyawan_model->getdatabyid($id_karyawan);
        $this->load->view('admin/edit_karyawan', $data);
    }

    public function editdata()
    {
        $id_karyawan = $this->input->post('id_karyawan');
        $nama_karyawan = $this->input->post('nama_karyawan');
        $username = $this->input->post('username');
        $alamat_karyawan = $this->input->post('alamat_karyawan');
        $alamat_cabang = $this->input->post('alamat_cabang');
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');
        $status   = $this->input->post('status');
        $foto_karyawan      = $_FILES['foto_karyawan']['name'];
        if($foto_karyawan)
        {
            $config ['upload_path']         = './assets/foto/foto_karyawan';
            $config ['allowed_types']       = 'jpg|jpeg|png|tiff';

            $this->load->library('upload', $config);
            
            if($this->upload->do_upload('foto_karyawan'))
            {
                $foto_karyawan=$this->upload->data('file_name');
                $this->db->set('foto_karyawan', $foto_karyawan);
            }
            else
            {
                echo $this->upload->display_errors();
            }
        }
        
    
        $data = array(
            'nama_karyawan' => $nama_karyawan,
            'alamat_karyawan' => $alamat_karyawan,
            'email' => $email,
            'alamat_cabang' => $alamat_cabang,
            'no_telepon' => $no_telepon,
            'username' => $username,
            'password' => $password,
            'status' => $status,
             
        );
        
        $kondisi = array(
            'id_karyawan' => $id_karyawan,
        );

        $update = $this->Karyawan_model->update($data, $kondisi);
        if($update){
            redirect('admin/karyawan/karyawan','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }

    function hapus($id_karyawan)
    {
        $gambar = new Karyawan_model; 

        if($gambar->checkProductImage($id_karyawan)){ 
            $data = $gambar->checkProductImage($id_karyawan);
            if (file_exists("./assets/foto/foto_karyawan/".$data->foto_karyawan)) {
                unlink("./assets/foto/foto_karyawan/".$data->foto_karyawan); 
            }

            $kondisi = array(
                'id_karyawan' => $id_karyawan,
            );
    
            $delete = $this->Karyawan_model->delete($kondisi); 
            $this->session->set_flashdata('status','Data berhasil di hapus');            
            if($delete){
                redirect('admin/karyawan/karyawan','refresh');
            }else{
                echo 'Data gagal Disimpan';
            }
           
        }
    }
    

}

?>