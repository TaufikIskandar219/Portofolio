<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Order extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Karyawan_model');
        $this->load->model('Layanan_model');
        $this->load->model('Order_model');
        $this->load->model('Penggajian_model');
    }

    public function index()
    {
        $data['karyawan'] = $this->Karyawan_model->getdata();
        if ($this->input->post('keyword')) {
            $data['karyawan'] = $this->Karyawan_model->carikaryawan();
        }
        $this->load->view('pelanggan/barberman', $data);
    }
    public function detail_karyawan($id_karyawan)
    {
        $data['detail'] = $this->Karyawan_model->ambil_id_karyawan($id_karyawan);
        $data['layanan'] = $this->Layanan_model->getdata();
        $data['pembayaran'] = $this->Penggajian_model->getdata();
        $this->load->view('pelanggan/tambah_order', $data);
    }
    public function tambah()
    {
        date_default_timezone_set("Asia/Jakarta");
        $id_pelanggan = $this->session->userdata('id_pelanggan');
        $id_karyawan = $this->input->post('id_karyawan');
        $id_layanan = $this->input->post('id_layanan');
        $keterangan = $this->input->post('keterangan');
        $tanggal_pesanan = date('Y-m-d H:i:s');


        $data = array(
            'id_pelanggan' => $id_pelanggan,
            'id_karyawan' => $id_karyawan,
            'id_layanan' => $id_layanan,
            'tanggal_pesanan' => $tanggal_pesanan,
            'keterangan' => $keterangan,
            'status_pesanan' => 'Belum Selesai',
            'status_pembayaran' => 'Belum Lunas'
        );

        $status_pesanan = array(
            'status_pesanan' => '0'
        );
        $status_pembayaran = array(
            'status_pembayaran' => '0'
        );


        $id_karyawan = array(
            'id_karyawan' => $id_karyawan
        );

        $save = $this->Order_model->save($data);
        if ($save) {
            redirect('pelanggan/order', 'refresh');
        } else {
            echo 'Data gagal disimpan!!';
        }

        redirect('pelanggan/dashboard');
    }


}

?>