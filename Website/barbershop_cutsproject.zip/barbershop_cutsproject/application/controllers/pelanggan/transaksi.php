<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Transaksi extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Order_model');
    }

    public function index()
    {
        $pelanggan = $this->session->userdata('id_pelanggan');
        $data['pesanan'] = $this->db->query("SELECT * FROM pesanan ps, pelanggan pl, karyawan ky, Layanan ly WHERE ps.id_pelanggan=pl.id_pelanggan AND ps.id_karyawan=ky.id_karyawan AND ps.id_layanan=ly.id_layanan AND pl.id_pelanggan='$pelanggan' ORDER BY id_pesanan DESC")->result();
        $this->load->view('pelanggan/transaksi', $data);
    }

    function hapus($id_pesanan)
    {

        $kondisi = array(
            'id_pesanan' => $id_pesanan,
        );

        $delete = $this->Order_model->delete($kondisi);
        $this->session->set_flashdata('status', 'Data berhasil di hapus');
        if ($delete) {
            redirect('pelanggan/transaksi', 'refresh');
        } else {
            echo 'Data gagal Disimpan';
        }
    }
}