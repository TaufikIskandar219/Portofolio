<?php
defined('BASEPATH') or exit('No direct script access allowed');

class dashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pelanggan_model');
        $this->load->model('Barbershop_model');
    }

    public function index()
    {

        $data['pelanggan'] = $this->Pelanggan_model->getdata();
        $data['barbershop'] = $this->Barbershop_model->getdata();
        $this->load->view('pelanggan/home', $data);
    }
}

?>