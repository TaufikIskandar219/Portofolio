<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Pelanggan_model');
	}

	public function index()
	{
		$data['pelanggan'] = $this->Pelanggan_model->getdata();
		$this->load->view('auth/login', $data);
	}

	public function tambah()
    {
        $id_pelanggan = $this->input->post('id_pelanggan');
        $nama_pelanggan = $this->input->post('nama_pelanggan');
        $email_pelanggan = $this->input->post('email_pelanggan');
        $password = md5($this->input->post('password'));
        $no_telepon = $this->input->post('no_telepon');

        $data = array(
            'id_pelanggan' => $id_pelanggan,
            'nama_pelanggan' => $nama_pelanggan,
            'email_pelanggan' => $email_pelanggan,
            'password' => $password,
            'no_telepon' => $no_telepon,
        );

        $save = $this->Pelanggan_model->save($data);
        if($save){
            redirect('login','refresh');
        }else{
            echo 'Data gagal Disimpan';
        }
    }

}