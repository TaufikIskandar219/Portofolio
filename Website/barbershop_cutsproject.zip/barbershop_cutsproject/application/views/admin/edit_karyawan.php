<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view("_partial/navbar"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("_partial/sidebar"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Edit Data Karyawan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Edit Data</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="col-lg-8">
                        <div class="card shadow mb-4">
                            <div class="card-body">
                                <?php foreach ($dataedit as $row): ?>
                                    <form action="<?php echo base_url(); ?>admin/karyawan/editdata" method="post"
                                        enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="id_karyawan">Id Karyawan</label>
                                            <input type="text" name="id_karyawan" value="<?php echo $row->id_karyawan ?>"
                                                class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="nama">Nama</label>
                                            <input type="text" name="nama_karyawan"
                                                value="<?php echo $row->nama_karyawan ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="username">Username</label>
                                            <input type="text" name="username" value="<?php echo $row->username ?>"
                                                class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="alamat">Alamat</label>
                                            <input type="text" name="alamat_karyawan"
                                                value="<?php echo $row->alamat_karyawan ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="alamat">Alamat Cabang</label>
                                            <input type="text" name="alamat_cabang"
                                                value="<?php echo $row->alamat_cabang ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" name="email"
                                                value="<?php echo $row->email ?>" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="text" name="password" value="<?php echo $row->password ?>"
                                                class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="telepon">No. telepon</label>
                                            <input type="number" name="no_telepon" value="<?php echo $row->no_telepon ?>"
                                                class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="status">Status</label>
                                            <select name="status" class="form-control">
                                                <option value="">--Pilih Status</option>
                                                <option value="1">Tersedia</option>
                                                <option value="0">Tidak Tersedia</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="foto">Foto Karyawan</label>
                                            <input type="file" name="foto_karyawan"
                                                value="<?php echo $row->foto_karyawan ?>" class="form-control">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                        <button type="reset" class="btn btn-warning">Reset</button>
                                    </form>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- /.Footer -->

        <?php $this->load->view("_partial/footer"); ?>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <?php $this->load->view("_partial/js"); ?>

</body>

</html>