<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view("_partial/navbar"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("_partial/sidebar"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Data Karyawan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Data Karyawan</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">DataTable with default features</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Foto Karyawan</th>
                                                <th>Nama </th>
                                                <th>Alamat</th>
                                                <th>Email</th>
                                                <th>Cabang</th>
                                                <th>No Telepon</th>
                                                <th>Status</th>
                                                <th>Opsi</th>
                                            </tr>
                                        </thead>
                                        <?php $no = 1;
                                        foreach ($karyawan as $row): ?>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <?php echo $no++; ?>
                                                    </td>
                                                    <td><img src="<?php echo base_url('assets/foto/foto_karyawan/') . $row->foto_karyawan; ?>"
                                                            width="100" height="100" class=""></td>
                                                    <td>
                                                        <?php echo $row->nama_karyawan; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $row->alamat_karyawan; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $row->email; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $row->alamat_cabang; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $row->no_telepon; ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        if ($row->status == "0") {
                                                            echo "<span class='badge badge-danger' style='background: darkred'> Tidak Tersedia</span>";
                                                        } elseif ($row->status == "1") {
                                                            echo "<span class='badge badge-primary' style='background: darkblue'>Tersedia</span>";
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url(); ?>admin/karyawan/hapus/<?php echo $row->id_karyawan; ?>"
                                                            class="btn btn-primary btn-circle btn-sm" data-toggle="tooltip"
                                                            title="Delete"
                                                            onclick="return confirm('Apakah data akan dihapus?')"><i
                                                                class="fa fa-trash"></i></a>
                                                        <a href="<?php echo base_url(); ?>admin/karyawan/getedit/<?php echo $row->id_karyawan; ?>"
                                                            class="btn btn-primary btn-circle btn-sm" data-toggle="tooltip"
                                                            title="Edit"><i class="fa fa-edit"></i></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        <?php endforeach ?>
                                    </table>
                                </div>
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php $this->load->view("_partial/footer"); ?>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <?php $this->load->view("_partial/js"); ?>

</body>

</html>