<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">
    <!-- Navbar -->
    <?php $this->load->view("_partial/navbar"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php $this->load->view("_partial/sidebar"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Edit Data Pelanggan</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Edit Data Pelanggan</li>
              </ol>
            </div>
          </div>
        </div>
      </section>
      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="main-content">
                <section class="section">
                  <div class="col-lg-8">
                    <div class="card shadow mb-4">
                      <div class="card-body">
                        <?php foreach ($dataedit as $row): ?>
                          <form action="<?php echo base_url(); ?>admin/barbershop/editdata" method="post"
                            enctype="multipart/form-data">
                            <div class="form-group">
                              <label for="id_pelanggan">Id Barbershop</label>
                              <input type="text" name="id_barbershop" value="<?php echo $row->id_barbershop ?>"
                                class="form-control">
                            </div>
                            <div class="form-group">
                              <label for="name">Alamat Cabang</label>
                              <input type="text" name="alamat_barbershop" value="<?php echo $row->alamat_barbershop ?>"
                                class="form-control">
                            </div>
                            <div class="form-group">
                              <label for="name">Deskripsi Cabang</label>
                              <input type="text" name="deskripsi" value="<?php echo $row->deskripsi ?>"
                                class="form-control">
                            </div>
                            <div class="form-group">
                              <label for="telepon">No. WhatsApps</label>
                              <input type="number" name="no_wa" value="<?php echo $row->no_wa ?>"
                                class="form-control">
                            </div>
                            <button type="submit" name="submit" class="btn btn-success">Submit</button>
                            <button type="reset" class="btn btn-warning">Reset</button>
                          </form>
                        <?php endforeach ?>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- /.Footer -->

    <?php $this->load->view("_partial/footer"); ?>
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->
  <?php $this->load->view("_partial/js"); ?>

</body>

</html>