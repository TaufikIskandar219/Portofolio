<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view("_partial/navbar"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("_partial/sidebar"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Edit Data Pesanan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Edit Data Pesanan</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="col-lg-8">
                        <div class="card shadow mb-4">
                            <div class="card-body">
                                <?php foreach ($dataedit as $row): ?>
                                    <form action="<?php echo base_url(); ?>admin/data_pesanan/editdata" method="post"
                                        enctype="multipart/form-data">
                                        <input type="hidden" name="id_pesanan" value="<?php echo $row->id_pesanan ?>">
                                        <div class="form-group">
                                            <label>Tanggal Pesanan</label>
                                            <option class="form-control " value="<?php echo $row->tanggal_pesanan ?>"><?php echo $row->tanggal_pesanan ?></option>
                                        </div>
                                        <div class="form-group">
                                            <label>Status Pesanan</label>
                                            <select name="status_pesanan" class="form-control">
                                                <option value="<?php echo $row->status_pesanan ?>"><?php echo $row->status_pesanan ?></option>
                                                <option value="Selesai">Selesai</option>
                                                <option value="Belum Selesai">Belum Selesai</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Status Pembayaran</label>
                                            <select name="status_pembayaran" class="form-control">
                                                <option value="<?php echo $row->status_pembayaran ?>"><?php echo $row->status_pembayaran ?></option>
                                                <option value="Lunas">Lunas</option>
                                                <option value="Belum Lunas">Belum Lunas</option>
                                                <option value="Batal">Batal, Tidak Melakukan Pembayaran</option>
                                            </select>
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                        <button type="reset" class="btn btn-warning">Reset</button>
                                    </form>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php $this->load->view("_partial/footer"); ?>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <?php $this->load->view("_partial/js"); ?>

</body>

</html>