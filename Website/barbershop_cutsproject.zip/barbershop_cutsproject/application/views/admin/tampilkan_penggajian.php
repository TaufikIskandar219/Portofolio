<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view("_partial/navbar"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("_partial/sidebar"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Data Gaji Barberman</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Data Gaji Barberman</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">DataTable with default features</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="col-lg-12 col-md-12 col-12 col-sm-12 ">



                                    <div class="card card-dark">
                                        <div class="card-body">
                                            <table id="example1" style="color: black"
                                                class="table table-bordered table-striped">

                                                <thead>
                                                    <tr>
                                                        <th>NO</th>
                                                        <th>TANGGAL</th>
                                                        <th>PELANGGAN</th>
                                                        <th>KAPSTER</th>
                                                        <th>LAYANAN</th>
                                                        <th>TARIF</th>
                                                        <th>STATUS PEMBAYARAN</th>
                                                        <th>STATUS PESANAN</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $no = 1;
                                                    $total = 0;
                                                    $semua = 0;
                                                    $tunai = 0;
                                                    foreach ($laporan as $ps): ?>
                                                        <tr>
                                                            <td>
                                                                <?php echo $no++ ?>
                                                            </td>
                                                            <td>
                                                                <?php echo date('d/m/Y', strtotime($ps->tanggal_pesanan)); ?>
                                                            </td>
                                                            <td>
                                                                <?php echo $ps->nama_pelanggan ?>
                                                            </td>
                                                            <td style="color: red"><b>
                                                                    <?php echo $ps->nama_karyawan ?>
                                                                </b></td>
                                                            <td>
                                                                <?php echo $ps->nama_layanan ?>
                                                            </td>

                                                            <td>Rp.
                                                                <?php echo number_format($ps->tarif, 0, ',', '.') ?>
                                                            </td>
                                                            <td>
                                                                <?php echo $ps->status_pembayaran ?>
                                                            </td>
                                                            <td>
                                                                <?php if ($ps->status_pesanan == "Selesai") {
                                                                    echo "Selesai";
                                                                } else {
                                                                    echo "Belum Selesai";
                                                                } ?>
                                                            </td>
                                                        </tr>

                                                        <?php
                                                        $total = ($total + $ps->tarif);
                                                    endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>


                                    <div class="card">
                                        <div class="card-body">
                                            <table style="color: black"
                                                class="table-responsive table table-border table-striped mt-3">
                                                </tbody>
                                                <tr>
                                                    <td colspan="6" class="text-right"><b>TOTAL :</b></td>
                                                    <td colspan="2"><b>Rp.
                                                            <?php echo number_format($total, 0, ',', '.') ?>
                                                        </b></td>
                                                </tr>
                                                <!--<tr>
        <td colspan="6" class="text-right"><b>TUNAI :</b></td>
        <td colspan="2"><b>Rp. <?php echo number_format($semua, 0, ',', '.') ?></b></td>
      </tr>
      <tr>
        <td colspan="6" class="text-right"><b>NON-TUNAI :</b></td>
        <td colspan="2"><b>Rp. <?php echo number_format($semua, 0, ',', '.') ?></b></td>
      </tr>-->
                                                <tr>
                                                    <td colspan="6" class="text-right"><b>GAJI = 40% x TOTAL :</b></td>
                                                    <td colspan="2"><b>Rp.
                                                            <?php echo number_format($total * (40 / 100), 0, ',', '.') ?>
                                                        </b></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <?php $this->load->view("_partial/footer"); ?>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
        </aside>
    </div>
    <!-- ./wrapper -->
    <?php $this->load->view("_partial/js"); ?>

</body>

</html>