<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view("_partial/navbar"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("_partial/sidebar"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Filter Penggajian</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Data Penggajian</li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">DataTable with default features</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="col-lg-12 col-md-12 col-12 col-sm-12 ">
                                    <form method="POST" action="<?php echo base_url('admin/penggajian') ?>">
                                        <table style="width: 100%; color: black" class="mb-4">
                                            <tr>
                                                <th>Dari Tanggal :</th>
                                                <th>Sampai Tanggal :</th>
                                                <th>Nama Kapster :</th>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <input type="date" name="dari" class="form-control">
                                                    <?php echo form_error('dari', '<span class="text-small text-danger">', '</span>') ?>
                                                </td>
                                                <td>
                                                    <input type="date" name="sampai" class="form-control">
                                                    <?php echo form_error('sampai', '<span class="text-small text-danger">', '</span>') ?>
                                                </td>
                                                <td>
                                                    <select name="id_karyawan" class="form-control" id="">
                                                        <option value="">--Pilih karyawan--</option>
                                                        <?php foreach ($karyawan as $ky): ?>
                                                            <option value="<?php echo $ky->id_karyawan ?>">
                                                                <?php echo $ky->nama_karyawan ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                    <?php echo form_error('id_karyawan', '<div class="text-small text-danger">', '</div>') ?>
                                                </td>
                                            </tr>
                                        </table>
                                        <button style="background: teal; color: white" type="submit"
                                            class="btn btn-sm shadow-dark"><i class="fas fa-eye"></i> Tampilkan
                                            Data</button>
                                    </form>
                                </div>
                                <br>
                            
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php $this->load->view("_partial/footer"); ?>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <?php $this->load->view("_partial/js"); ?>

</body>

</html>