<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
<!-- Page Content-->
<div class="container px-6 px-lg-4">
    <!-- Heading Row-->

    <!-- Call to Action-->
    <div class="card bg-dark text-white my-6 py-4 text-center">
        <div class="card-body">
            <h2 class="text-white m-0">Transaksi</h2>
        </div>
    </div>
    <!-- Content Row-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css">

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Data Pesanan</h3>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped projects">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Pelanggan</th>
                        <th>Nama Barberman</th>
                        <th>Layanan</th>
                        <th>Tarif </th>
                        <th> Status Pesanan</th>
                        <th>Status pembayaran</th>
                        <th>Komentar </th>
                        <th>Aksi </th>
                    </tr>
                </thead>
                <?php $no = 1;
                foreach ($pesanan as $row): ?>
                    <tbody>
                        <tr>
                            <td>
                                <?php echo $no++ ?>
                            </td>
                            <td>
                                <?php echo date('d-m-Y H:i:s', strtotime($row->tanggal_pesanan)); ?>
                            </td>
                            <td>
                                <?php echo $row->nama_pelanggan ?>
                            </td>
                            <td>
                                <?php echo $row->nama_karyawan ?>
                            </td>
                            <td>
                                <?php echo $row->nama_layanan ?>
                            </td>
                            <td>
                                <?php echo $row->tarif ?>
                            </td>
                            <td>
                                <?php
                                if ($row->status_pesanan == "Belum Selesai") {
                                    echo "<span class='badge badge-danger' style='background: darkred'> Pesanan Diterima</span>";
                                } elseif ($row->status_pesanan == "Selesai") {
                                    echo "<span class='badge badge-primary' style='background: darkblue'>Selesai</span>";
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($row->status_pembayaran == "Belum Lunas") {
                                    echo "<span class='badge badge-danger' style='background: darkred'> Segera Lakukan Pembayaran</span>";
                                } elseif ($row->status_pembayaran == "Batal") {
                                    echo "<span class='badge badge-primary' style='background: darkred'>Batal, Tidak Melakukan Pembayaran</span>";
                                }elseif ($row->status_pembayaran == "Lunas") {
                                    echo "<span class='badge badge-primary' style='background: darkblue'>Lunas</span>";
                                }
                                ?>
                            </td>
                            <td>
                                <?php echo $row->keterangan ?>
                            </td>
                            <td class="project-actions text-right">
                                <a class="btn btn-danger btn-sm"
                                    href="<?php echo base_url(); ?>pelanggan/transaksi/hapus/<?php echo $row->id_pesanan; ?>">
                                    <i class="fa fa-trash">
                                    </i>
                                    Batal
                                </a>
                            </td>
                        </tr>
                    </tbody>
                <?php endforeach ?>
            </table>
        </div>

    </div>
</div>

<!-- Footer-->

<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?php echo base_url(); ?>assets/pelanggan/js/scripts.js"></script>
</body>

</html>