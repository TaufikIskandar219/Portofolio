<?php 

  $email = $this->session->userdata('email');
  if(empty($email))
  {
    redirect('auth/login');
  }

 ?>
<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
        <!-- Page Content-->
        <div class="container px-4 px-lg-5">
            <!-- Heading Row-->
            <div class="row gx-4 gx-lg-5 align-items-center my-5">
                <div class="col-lg-7"><img class="img-fluid rounded mb-4 mb-lg-0" src="<?php echo base_url(); ?>assets/pelanggan/foto/gallery3.png" alt="" /></div>
                <div class="col-lg-5">
                    <h1 class="font-weight-light">Barbershop Cut Project</h1>
                    <p>Selamat datang di Barbershop Cuts Project, kami sangat mengutamakan kepuasan bagi pelanggan dengan memberikan layanan yang berkualitas</p>
                </div>
            </div>
            <!-- Call to Action-->
            <div class="card text-white bg-secondary my-5 py-4 text-center">
                <div class="card-body"><p class="text-white m-0">Pilih Cabang terdekat</p></div>
            </div>
            <!-- Content Row-->
            <div class="container">
        <div class="row mt-n5">
        <?php foreach ($barbershop as $row) : ?>
            <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".2s"
                style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                <div class="blog-grid">
                    <div class="blog-grid-img position-relative"><img alt="img"
                            src="<?php echo base_url(); ?>assets/pelanggan/foto/logo_barber.jpg"></div>
                    <div class="blog-grid-text p-4">
                        <h3 class="h5 mb-3"><a href="#!"><?php echo $row->alamat_barbershop ?></a></h3>
                        <p class="display-30"><?php echo $row->deskripsi ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
       
        <div class="row mt-6 wow fadeInUp" data-wow-delay=".6s"
            style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <div class="col-12">
                <div class="pagination text-small text-uppercase text-extra-dark-gray">
                    <ul>
                        <li><a href="#!"><i class="fas fa-long-arrow-alt-left me-1 d-none d-sm-inline-block"></i>
                                Prev</a></li>
                        <li class="active"><a href="#!">1</a></li>
                        <li><a href="#!">2</a></li>
                        <li><a href="#!">3</a></li>
                        <li><a href="#!">Next <i
                                    class="fas fa-long-arrow-alt-right ms-1 d-none d-sm-inline-block"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
        </div>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container px-4 px-lg-5"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2023</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo base_url(); ?>assets/pelanggan/js/scripts.js"></script>
    </body>
</html>
