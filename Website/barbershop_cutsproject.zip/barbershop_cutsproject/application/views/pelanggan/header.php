
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Small Business - Start Bootstrap Template</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/pelanggan/assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo base_url(); ?>assets/pelanggan/css/styles.css" rel="stylesheet" />
    <!-- Profil -->
    <link href="<?php echo base_url(); ?>assets/pelanggan/css/profil.css" rel="stylesheet">
    <!-- Profil -->
    <link href="<?php echo base_url(); ?>assets/pelanggan/css/pembayaran.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/pelanggan/css/navbar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link href="<?php echo base_url(); ?>assets/pelanggan/css/barberman.css" rel="stylesheet">
    


    <!-- aseets -->
    <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">
</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container px-6">
            <a class="navbar-brand" href="#!">Barbershop Cuts Project</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="<?php echo site_url('pelanggan/dashboard'); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo site_url('pelanggan/order'); ?>">Barberman</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo site_url('pelanggan/transaksi'); ?>">Transaksi</a></li>
                    <li class="nav-item"><a class="nav-link active" href="<?php echo site_url('pelanggan/pembayaran'); ?>">Pembayaran</a></li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-4" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i> <?php echo $this->session->userdata('nama_pelanggan') ?></a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-cyan" aria-labelledby="navbarDropdownMenuLink-4">
                    <a class="dropdown-item" href="#">Profil</a>
                    <a class="dropdown-item" href="<?php echo site_url('Auth/logout'); ?>">Log out</a>
                    </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <?php $this->load->view("_partial/js"); ?>