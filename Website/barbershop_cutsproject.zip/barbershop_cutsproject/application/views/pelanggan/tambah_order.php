<?php

defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Asia/Jakarta');
?>
<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
<!-- Page Content-->
<div class="container px-4 px-lg-5">
	<!-- Heading Row-->

	<!-- Call to Action-->
	<div class="card bg-dark text-white my-6 py-6 text-center">
		<div class="card-body">
			<h2 class="text-white m-0">Pesan Barberman</h2>
		</div>
	</div>
	<!-- Content Row-->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css">

	<div class="container">
		<div class="main-body">
			<div class="row">
				<div class="col-lg-7">
					<div class="card">
						<div class="card-body">
							<div class="table-responsive">
								<table class="table mb-0">
									<thead class="small text-uppercase bg-body text-muted">
										<tr>
											<th>NO</th>
											<th>Nama Layanan</th>
											<th>Keterangan</th>
											<th>Tarif</th>
										</tr>
									</thead>
									<?php $no = 1;
									foreach ($layanan as $row): ?>
										<tbody>
											<tr class="align-middle">
												<td>
													<?php echo $no++; ?>
												</td>
												<td>
													<?php echo $row->nama_layanan; ?>
												</td>
												<td>
													<?php echo $row->ket_layanan; ?>
												</td>
												<td>
													<?php echo $row->tarif; ?>
												</td>
											</tr>
										</tbody>
									<?php endforeach ?>
								</table>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-5">
					<div class="card shadow mb-4">
						<div class="card-body">
							<form action="<?php echo base_url(); ?>pelanggan/order/tambah" method="post"
								enctype="multipart/form-data">
								<?php foreach ($detail as $dtl): ?>
									<div class="form-group">
										<label for="nama">Nama Barberman</label>
										<input type="hidden" name="id_karyawan" value="<?php echo $dtl->id_karyawan ?>"
											class="form-control">
										<input type="text" name="nama_karyawan" class="form-control"
											value="<?php echo $dtl->nama_karyawan ?>" readonly>
									</div>
								<?php endforeach; ?>
								<div class="form-group">
									<label for="username">Nama Layanan</label>
									<select name="id_layanan" class="form-control">
										<option value="">--Pilih Layanan--</option>
										<?php foreach ($layanan as $row): ?>
											<option value="<?php echo $row->id_layanan ?>"><?php echo $row->nama_layanan ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="form-group">
									<label><b>Waktu Pesan :</b></label>
									<input name="tanggal_pesanan" class="form-control" readonly=""
										placeholder="<?php echo date('d F Y H:i:s') ?>">
								</div>
	
								<div class="form-group">
									<label><b>Keterangan :</b></label>
									<input name="keterangan" class="form-control" 
										placeholder="waktu || Alamat Pelayanan">
								</div>
								<button type="submit" name="submit" class="btn btn-success">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<br>
<br>
<!-- Footer-->

<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?php echo base_url(); ?>assets/pelanggan/js/scripts.js"></script>
</body>

</html>