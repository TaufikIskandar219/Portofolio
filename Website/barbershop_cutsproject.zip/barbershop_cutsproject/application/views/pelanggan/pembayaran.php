<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
<!-- Page Content-->
<div class="container px-4 px-lg-5">
    <!-- Heading Row-->

    <!-- Call to Action-->
    <div class="card bg-dark text-white my-5 py-4 text-center">
        <div class="card-body">
            <h2 class="text-white m-0">Pembayaran Non Tunai</h2>
        </div>
    </div>
    <!-- Content Row-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css"
        integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />

    <div class="container">
        <div class="row mt-n5">
        <?php foreach ($pembayaran as $byr): ?>
            <div class="col-md-6 col-lg-4 mt-5 wow fadeInUp" data-wow-delay=".2s"
                style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                <div class="blog-grid">
                    <div class="blog-grid-img position-relative"><img alt="img"
                            src="<?php echo base_url('assets/foto/foto_pembayaran/') . $byr->foto_pembayaran; ?>"></div>
                    <div class="blog-grid-text p-4">
                        <h3 class="h5 mb-3"><a href="#!"><?php echo $byr->nama_bank ?></a></h3>
                        <p class="display-30"><?php echo $byr->atas_nama ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach ?>
        </div>
        <div class="row mt-6 wow fadeInUp" data-wow-delay=".6s"
            style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <div class="col-12">
                <div class="pagination text-small text-uppercase text-extra-dark-gray">
                    <ul>
                        <li><a href="#!"><i class="fas fa-long-arrow-alt-left me-1 d-none d-sm-inline-block"></i>
                                Prev</a></li>
                        <li class="active"><a href="#!">1</a></li>
                        <li><a href="#!">2</a></li>
                        <li><a href="#!">3</a></li>
                        <li><a href="#!">Next <i
                                    class="fas fa-long-arrow-alt-right ms-1 d-none d-sm-inline-block"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<br>
<!-- Footer-->
<?php $this->load->view("pelanggan/footer"); ?>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?php echo base_url(); ?>assets/pelanggan/js/scripts.js"></script>
</body>

</html>