<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
<!-- Page Content-->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js"
	data-client-key="SB-Mid-client-izOVxKi1vLALOm0j"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<body>
	<div class="container content">
		<div class="card bg-dark text-white my-5 py-4 text-center">
			<div class="card-body">
				<h2 class="text-white m-0">Pembayaran</h2>
			</div>
		</div>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

		<div class="container">
			<div class="main-body">
				<div class="row">
					<div class="col-lg-7">
						<div class="card">
							<div class="card-body">
								<div class="table-responsive">
									<table class="table mb-0">
										<thead class="small text-uppercase bg-body text-muted">
										<p class="text-success mb-3">*). Pastikan Pelanggan Melakukan Pembayaran 1x 24 Jam Setelah Membuat Pesanan, Atau Pesanan Akan Dibatalkan Oleh Admin</p>
											<tr>
												<th>NO</th>
												<th>Nama Layanan</th>
												<th>Keterangan</th>
												<th>Tarif</th>
											</tr>
										</thead>
										<?php $no = 1;
										foreach ($layanan as $row): ?>
											<tbody>
												<tr class="align-middle">
													<td>
														<?php echo $no++; ?>
													</td>
													<td>
														<?php echo $row->nama_layanan; ?>
													</td>
													<td>
														<?php echo $row->ket_layanan; ?>
													</td>
													<td>
														<?php echo $row->tarif; ?>
													</td>
												</tr>
											</tbody>
										<?php endforeach ?>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="col-lg-5">
						<div class="card shadow mb-4">
							<div class="card-body">
								<form id="payment-form" method="post"
									action="<?= site_url() ?>/pelanggan/pembayaran/finish">
									<input type="hidden" name="result_type" id="result-type" value="">
									<input type="hidden" name="result_data" id="result-data" value="">
									<div class="row">
										<div class="col md-4">
											<div class="form-group">
												<label for="nama_layanan">Nama Layanan</label>
												<input type="text" class="form-control" placeholder="Nama Layanan"
													name="nama_layanan" id="nama_layanan" required>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col md-4">
											<div class="form-group">
												<label for="tarif">Total Pembayaran</label>
												<input type="number" class="form-control"
													placeholder="Jumlah Pembayaran" name="tarif" id="tarif" required>
											</div>
										</div>
									</div>
									<button id="pay-button" class="btn btn-success">Submit</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


		<script type="text/javascript">

			$('#pay-button').click(function (event) {
				event.preventDefault();
				$(this).attr("disabled", "disabled");

				var nama_layanan = $("#nama_layanan").val();
				var tarif = $("#tarif").val();
				$.ajax({
					type: 'POST',
					url: '<?= site_url() ?>/snap/token',
					data: {
						nama_layanan: nama_layanan,
						tarif: tarif
					},
					cache: false,

					success: function (data) {
						//location = data;

						console.log('token = ' + data);

						var resultType = document.getElementById('result-type');
						var resultData = document.getElementById('result-data');

						function changeResult(type, data) {
							$("#result-type").val(type);
							$("#result-data").val(JSON.stringify(data));

						}

						snap.pay(data, {

							onSuccess: function (result) {
								changeResult('success', result);
								console.log(result.status_message);
								console.log(result);
								$("#payment-form").submit();
							},
							onPending: function (result) {
								changeResult('pending', result);
								console.log(result.status_message);
								$("#payment-form").submit();
							},
							onError: function (result) {
								changeResult('error', result);
								console.log(result.status_message);
								$("#payment-form").submit();
							}
						});
					}
				});
			});

		</script>
</body>