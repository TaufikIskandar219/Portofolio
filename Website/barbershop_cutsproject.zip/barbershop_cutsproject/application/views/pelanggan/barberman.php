<!DOCTYPE html>
<html lang="en">
<?php $this->load->view("pelanggan/header"); ?>
<!-- Page Content-->
<div class="container px-4 px-lg-5">
    <!-- Heading Row-->

    <!-- Call to Action-->
    <div class="card bg-dark text-white my-5 py-4 text-center">
        <div class="card-body">
            <h2 class="text-white m-0">Barberman</h2>
        </div>
    </div>
    <!-- Content Row-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css">

    <div class="container">
        <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-4">
            <?php foreach ($karyawan as $row): ?>
                <div class="col">
                    <div class="card radius-20">
                        <div class="card-body text-center">
                            <div class="p-4 border radius-15">
                                <img src="<?php echo base_url('assets/foto/foto_karyawan/') . $row->foto_karyawan; ?>" width="110" height="110"
                                    class="rounded-circle shadow" alt="">
                                <h5 class="mb-0 mt-5">
                                    <h6>
                                        <?php echo $row->nama_karyawan ?>
                                    </h6>
                                    <p class="mb-3">
                                        <?php echo $row->alamat_cabang ?>
                                    </p>
                                    <div class="list-inline contacts-social mt-3 mb-3">
                                        <a href="javascript:;" class="list-inline-item bg-twitter text-white border-0"><i
                                                class="bx bxl-instagram"></i></a>
                                        <a href="javascript:;" class="list-inline-item bg-linkedin text-white border-0"><i
                                                class="bx bxl-whatsapp"></i></a>
                                    </div>
                                    <div class="d-grid">
                                        <?php
                                        if ($row->status == "0") {
                                            echo "<button style='background:' class='btn btn-outline-primary radius-15' disable>Libur</button>";
                                        } elseif ($row->status == "1") {
                                            echo anchor('pelanggan/order/detail_karyawan/' . $row->id_karyawan, '<button style="background: teal; color:white" class="btn btn-outline-primary radius-15"><i class="fa fa-book"></i> Pesan Sekarang</button>');
                                        } else {
                                            echo "<button style='background:' class='btn btn-sm btn-danger mb-1' disable>Tutup</button>";
                                        }
                                        ?>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </div>
</div>
<!-- Footer-->
<br>
<br>
<br>
<?php $this->load->view("pelanggan/footer"); ?>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="<?php echo base_url(); ?>assets/pelanggan/js/scripts.js"></script>
</body>

</html>