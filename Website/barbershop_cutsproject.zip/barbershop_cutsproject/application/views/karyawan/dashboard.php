<?php
defined('BASEPATH') OR exit('No direct script access allowed');
  $email = $this->session->userdata('email');
  if(empty($email))
  {
    redirect('auth/login');
  }

 ?>

 <!-- Header -->
 
<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="<?php echo base_url(); ?>assets/dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <?php $this->load->view("karyawan/navbar_karyawan"); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php $this->load->view("karyawan/sidebar_karyawan"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-12 col-md-6 col-sm-6 col-12">
              <?php 
                  if($this->session->userdata('status') == "0"){
                      echo "<a class='btn btn-lg col-lg-12 mr-2 mb-4' style='background: darkred; color:white'><b>LIBUR</b></a>";
                  }elseif($this->session->userdata('status') == "1"){
                      echo "<a class='btn btn-lg col-lg-12 mr-2 mb-4' style='background: teal; color: white'><b>TERSEDIA</b></a>";
                  }else{
                      echo "<a class='btn btn-lg col-lg-12 mr-2 mb-4' style='background: darkred; color: white'><b>TIDAK TERSEDIA</b></a>";
                  }
              ?>
            </div>
          </div>
          <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo ($count['pesanan']); ?></h3>

                <p>Pesanan Masuk</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo ($count['selesai']); ?></h3>

                <p>Pesanan Selesai</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo ($count['semua']); ?></h3>

                <p>Total Pesanan</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
        </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-12 col-sm-12 ">
              <div class="card shadow-dark">
                <div class="card-body">
                   <div id="main-slider" class="owl-carousel owl-theme">
                      <img style="width: 100%" src="<?php echo base_url() ?>assets/foto/foto_karyawan/logo.png" >
                    </div>
                </div>
              </div>
            </div>
          </div>
          </div>
      </div><!-- /.container-fluid -->
    </section>
  </div>
  
  <!-- /.Footer -->
  <?php $this->load->view("_partial/footer"); ?>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<?php $this->load->view("_partial/js"); ?>