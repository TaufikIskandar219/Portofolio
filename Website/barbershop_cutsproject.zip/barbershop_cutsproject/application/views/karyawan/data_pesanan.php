<?php

$email = $this->session->userdata('email');
if (empty($email)) {
    redirect('auth/login');
}

?>

<!-- Header -->
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="<?php echo base_url(); ?>assets/dist/img/AdminLTELogo.png"
                alt="AdminLTELogo" height="60" width="60">
        </div>

        <!-- Navbar -->
        <?php $this->load->view("karyawan/navbar_karyawan"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("karyawan/sidebar_karyawan"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Data Pesanan</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Data Pesanan</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">DataTable with default features</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Tanggal</th>
                                                <th>Nama Pelanggan</th>
                                                <th>Layanan</th>
                                                <th>Tarif</th>
                                                <th>No WhatsApp</th>
                                                <th>Status Pesanan</th>
                                                <th>Status Pembayaran</th>
                                                <th>Keterangan</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <?php $no = 1;
                                        foreach ($pesanan as $ps): ?>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <?php echo $no++; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo date('d-m-Y H:i', strtotime($ps->tanggal_pesanan)); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->nama_pelanggan ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->nama_layanan; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->tarif; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->no_telepon; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->status_pesanan; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->status_pembayaran; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $ps->keterangan; ?>
                                                    </td>
                                                    <td>
                                                        <div class="row">
                                                            <a style="background: blue;" class="btn btn-sm btn-primary mr-2"
                                                                href="<?php echo base_url('Karyawan/data_pesanan/getedit/'.$ps->id_pesanan) ?> "><i
                                                                    class="fas fa-edit"></i></a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        <?php endforeach ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- /.Footer -->
        <?php $this->load->view("_partial/footer"); ?>

    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <?php $this->load->view("_partial/js"); ?>