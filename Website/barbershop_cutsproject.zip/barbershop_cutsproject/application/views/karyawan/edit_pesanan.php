<?php

$email = $this->session->userdata('email');
if (empty($email)) {
    redirect('auth/login');
}

?>

<!-- Header -->
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="<?php echo base_url(); ?>assets/dist/img/AdminLTELogo.png"
                alt="AdminLTELogo" height="60" width="60">
        </div>

        <!-- Navbar -->
        <?php $this->load->view("karyawan/navbar_karyawan"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("karyawan/sidebar_karyawan"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Edit Status Pemesanan</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Edit Data</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="col-lg-8">
                        <div class="card shadow mb-4">
                            <div class="card-body">
                                <?php foreach ($dataedit as $row): ?>
                                    <form action="<?php echo base_url(); ?>karyawan/data_pesanan/editdata" method="post"
                                        enctype="multipart/form-data">
                                        <input type="hidden" name="id_pesanan" value="<?php echo $row->id_pesanan ?>">
                                        <div class="form-group">
                                            <label>Tanggal Pesanan</label>
                                            <option class="form-control " value="<?php echo $row->tanggal_pesanan ?>"><?php echo $row->tanggal_pesanan ?></option>
                                        </div>
                                        <div class="form-group">
                                            <label>Status Pesanan</label>
                                            <select name="status_pesanan" class="form-control">
                                                <option value="<?php echo $row->status_pesanan ?>"><?php echo $row->status_pesanan ?></option>
                                                <option value="Selesai">Selesai</option>
                                                <option value="Belum Selesai">Belum Selesai</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Status Pembayaran</label>
                                            <select name="status_pembayaran" class="form-control">
                                                <option value="<?php echo $row->status_pembayaran ?>"><?php echo $row->status_pembayaran ?></option>
                                                <option value="Lunas">Lunas</option>
                                                <option value="Belum Lunas">Belum Lunas</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <input type="text" name="keterangan" value="<?php echo $row->keterangan ?>" class="form-control">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-success">Submit</button>
                                        <button type="reset" class="btn btn-warning">Reset</button>
                                    </form>
                                <?php endforeach ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- /.Footer -->
        <?php $this->load->view("_partial/footer"); ?>

    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <?php $this->load->view("_partial/js"); ?>