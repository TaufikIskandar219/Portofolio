<!-- Header -->
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<?php $this->load->view("_partial/header"); ?>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__shake" src="<?php echo base_url(); ?>assets/dist/img/AdminLTELogo.png"
                alt="AdminLTELogo" height="60" width="60">
        </div>

        <!-- Navbar -->
        <?php $this->load->view("karyawan/navbar_karyawan"); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view("karyawan/sidebar_karyawan"); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Pendapatan</h1>
                        </div><!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Pendapatan</li>
                            </ol>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">DataTable with default features</h3>
                                </div>
                                <!-- /.card-header -->
                                <div class="col-lg-12 col-md-12 col-12 col-sm-12 ">

                                    <form method="POST" action="<?php echo base_url('karyawan/pendapatan') ?>">
                                        <table style="width: 100%; color: black" class="mb-4">
                                            <tr>
                                                <th>Dari Tanggal :</th>
                                                <th>Sampai Tanggal :</th>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <input type="date" name="dari" class="form-control">
                                                    <?php echo form_error('dari', '<span class="text-small text-danger">', '</span>') ?>
                                                </td>
                                                <td>
                                                    <input type="date" name="sampai" class="form-control">
                                                    <?php echo form_error('sampai', '<span class="text-small text-danger">', '</span>') ?>
                                                </td>
                                            </tr>
                                        </table>

                                        <button style="background: teal; color: white" type="submit"
                                            class="btn btn-sm "><i class="fas fa-eye"></i> Tampilkan Data</button>
                                    </form>
                                    <hr>

                                    <div class="card-body">
                                        <table id="example1" class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Tanggal</th>
                                                    <th>Nama Pelanggan</th>
                                                    <th>Layanan</th>
                                                    <th>Tarif</th>
                                                    <th>No WhatsApp</th>
                                                    <th>Status Pesanan</th>
                                                </tr>
                                            </thead>
                                            <?php $no = 1;
                                            $total = 0;
                                            foreach ($pendapatan as $ps): ?>
                                                <tbody>
                                                    <tr>
                                                        <td>
                                                            <?php echo $no++; ?>
                                                        </td>
                                                        <td>
                                                            <?php echo date('d-m-Y H:i', strtotime($ps->tanggal_pesanan)); ?>
                                                        </td>
                                                        <td>
                                                            <?php echo $ps->nama_pelanggan ?>
                                                        </td>
                                                        <td>
                                                            <?php echo $ps->nama_layanan; ?>
                                                        </td>
                                                        <td>
                                                        Rp. <?php echo number_format($ps->tarif,0,',','.')  ?>
                                                        </td>
                                                        <td>
                                                            <?php echo $ps->no_telepon; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($ps->status_pesanan == "Selesai") {
                                                                echo "Selesai";
                                                            } else {
                                                                echo "Belum Selesai";
                                                            } ?>
                                                        </td>
                                                    </tr>
                                                    <?php
                            
                                                $total = $total + $ps->tarif; endforeach ?>
                                                </tbody>
                                                
                                            <tr>
                                                <td colspan="5" class="text-right"><b>TOTAL PEMASUKAN :</b></td>
                                                <td colspan="2"><b>Rp.
                                                        <?php echo number_format($total, 0, ',', '.') ?>
                                                    </b></td>
                                            </tr>
                                            <tr>
                                                <td colspan="5" class="text-right"><b>TOTAL PENDAPATAN :</b></td>
                                                <td colspan="2" style="color:red"><b>Rp.
                                                <?php echo number_format($total * (40/100), 0, ',', '.') ?>
                                                    </b></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- /.Footer -->
        <?php $this->load->view("_partial/footer"); ?>

    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <?php $this->load->view("_partial/js"); ?>