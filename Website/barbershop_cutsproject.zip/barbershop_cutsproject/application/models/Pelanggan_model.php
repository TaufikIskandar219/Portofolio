<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pelanggan_model extends CI_Model
{
  function getdata()
  {
    $query = $this->db->query("SELECT * FROM pelanggan ORDER BY id_pelanggan ASC");
    return $query->result();
  }

  function save($data)
  {
    $tambah = $this->db->insert('pelanggan', $data);
    return $tambah;
  }

  function getdatabyid($id_pelanggan)
  {
    $query = $this->db->query("SELECT * FROM pelanggan where id_pelanggan = '$id_pelanggan' ORDER BY id_pelanggan ASC");
    return $query->result();
  }

  function update($data, $kondisi)
  {
    $this->db->where($kondisi);
    $this->db->update('pelanggan', $data);
    return true;
  }
  function checkProductImage($id_pelanggan)
  {
    $query = $this->db->get_where('pelanggan', ['id_pelanggan' => $id_pelanggan]);
    return $query->row();
  }

  function delete($kondisi)
  {
    $this->db->where($kondisi);
    $this->db->delete('pelanggan');
    return true;
  }
}
