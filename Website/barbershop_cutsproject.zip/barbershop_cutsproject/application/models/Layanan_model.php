<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Layanan_model extends CI_Model
{
  function getdata()
  {
    $query = $this->db->query("SELECT * FROM layanan ORDER BY id_layanan ASC");
    return $query->result();
  }

  function save($data)
  {
    $tambah = $this->db->insert('layanan', $data);
    return $tambah;
  }

  function getdatabyid($id_layanan)
  {
    $query = $this->db->query("SELECT * FROM layanan where id_layanan = '$id_layanan' ORDER BY id_layanan ASC");
    return $query->result();
  }

  function update($data, $kondisi)
  {
    $this->db->where($kondisi);
    $this->db->update('layanan', $data);
    return true;
  }
  function checkProductImage($id_layanan)
  {
    $query = $this->db->get_where('layanan', ['id_layanan' => $id_layanan]);
    return $query->row();
  }

}
