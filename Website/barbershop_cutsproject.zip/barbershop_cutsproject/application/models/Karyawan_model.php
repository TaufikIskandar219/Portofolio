<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Karyawan_model extends CI_Model
{
  function getdata()
  {
    $query = $this->db->query("SELECT * FROM karyawan ORDER BY id_karyawan ASC");
    return $query->result();
  }

  function save($data)
  {
    $tambah = $this->db->insert('karyawan', $data);
    return $tambah;
  }

  function getdatabyid($id_karyawan)
  {
    $query = $this->db->query("SELECT * FROM karyawan where id_karyawan = '$id_karyawan' ORDER BY id_karyawan ASC");
    return $query->result();
  }

  function update($data, $kondisi)
  {
    $this->db->where($kondisi);
    $this->db->update('karyawan', $data);
    return true;
  }
  function checkProductImage($id_karyawan)
  {
    $query = $this->db->get_where('karyawan', ['id_karyawan' => $id_karyawan]);
    return $query->row();
  }

  function delete($kondisi)
  {
    $this->db->where($kondisi);
    $this->db->delete('karyawan');
    return true;
  }
  public function carikaryawan()
  {
    $keyword = $this->input->post('keyword', true);
    $this->db->like('nama_karyawan', $keyword);
    return $this->db->get('karyawan')->result_array();
  }
  public function ambil_id_karyawan($id_karyawan)
  {
    $hasil = $this->db->where('id_karyawan', $id_karyawan)->get('karyawan');
    if ($hasil->num_rows() > 0) {
      return $hasil->result();
    } else {
      return false;
    }
  }
  
}