<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth_model extends CI_Model{
    public function filter_data($namatabel,$filter){
    return $this->db->get_where($namatabel,$filter);
}



public function get_data($table){
    return $this->db->get($table);
}

public function get_where($where,$table){
    return $this->db->get_where($table,$where);
}

public function insert_data($data,$table){
    $this->db->insert($table,$data);
}

public function update_data($table,$data,$where){
    $this->db->update($table,$data,$where);
}

public function delete_data($where,$table){
    $this->db->where($where);
    $this->db->delete($table);
}

public function ambil_id_admin($id_admin)
{
    $hasil = $this->db->where('id_admin', $id_admin)->get('admin');
    if($hasil->num_rows() > 0 ){
        return $hasil->result();
    }else{
        return false;
    }
}

public function ambil_id_pembayaran($id_pembayaran)
{
    $hasil = $this->db->where('id_pembayaran', $id_pembayaran)->get('pembayaran');
    if($hasil->num_rows() > 0 ){
        return $hasil->result();
    }else{
        return false;
    }
}

public function ambil_id_karyawan($id_karyawan)
{
    $hasil = $this->db->where('id_karyawan', $id_karyawan)->get('karyawan');
    if($hasil->num_rows() > 0 ){
        return $hasil->result();
    }else{
        return false;
    }
}

public function ambil_id_layanan($id_layanan)
{
    $hasil = $this->db->where('id_layanan', $id_layanan)->get('layanan');
    if($hasil->num_rows() > 0 ){
        return $hasil->result();
    }else{
        return false;
    }
}

public function ambil_id_pelanggan($id_pelanggan)
{
    $hasil = $this->db->where('id_pelanggan', $id_pelanggan)->get('pelanggan');
    if($hasil->num_rows() > 0 ){
        return $hasil->result();
    }else{
        return false;
    }
}

public function ambil_id_pesanan($id_pesanan)
    {
        $hasil = $this->db->where('id_pesanan', $id_pesanan)->get('pesanan');
        if($hasil->num_rows() > 0 ){
            return $hasil->result();
        }else{
            return false;
        }
    }

public function cek_login_admin()
{
    $email = set_value('email');
    $password = set_value('password');

    $result = $this->db
                    ->where('email',$email)
                    ->where('password',md5($password))
                    ->limit(1)
                    ->get('admin');

    if($result->num_rows() > 0) {
        return $result->row();
    }else{
        return FALSE;
    }
}

public function cek_login_karyawan()
{
    $email = set_value('email');
    $password = set_value('password');

    $result = $this->db
                    ->where('email',$email)
                    ->where('password',md5($password))
                    ->limit(1)
                    ->get('karyawan');

    if($result->num_rows() > 0) {
        return $result->row();
    }else{
        return FALSE;
    }
}

public function cek_login_pelanggan()
{
    $email = set_value('email');
    $password = set_value('password');

    $result = $this->db
                    ->where('email',$email)
                    ->where('password',md5($password))
                    ->limit(1)
                    ->get('pelanggan');

    if($result->num_rows() > 0) {
        return $result->row();
    }else{
        return FALSE;
    }
}

}