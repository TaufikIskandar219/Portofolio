<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penggajian_model extends CI_Model
{
    public function filter_data($namatabel, $filter)
    {
        return $this->db->get_where($namatabel, $filter);
    }

    public function get_data($table)
    {
        return $this->db->get($table);
    }

    public function get_where($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    public function insert_data($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function update_data($table, $data, $where)
    {
        $this->db->update($table, $data, $where);
    }

    public function delete_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function ambil_id_admin($id_admin)
    {
        $hasil = $this->db->where('id_admin', $id_admin)->get('admin');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function ambil_id_bank($id_bank)
    {
        $hasil = $this->db->where('id_bank', $id_bank)->get('bank');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function ambil_id_karyawan($id_karyawan)
    {
        $hasil = $this->db->where('id_karyawan', $id_karyawan)->get('karyawan');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function ambil_id_layanan($id_layanan)
    {
        $hasil = $this->db->where('id_layanan', $id_layanan)->get('layanan');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function ambil_id_pelanggan($id_pelanggan)
    {
        $hasil = $this->db->where('id_pelanggan', $id_pelanggan)->get('pelanggan');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function ambil_id_pesanan($id_pesanan)
    {
        $hasil = $this->db->where('id_pesanan', $id_pesanan)->get('pesanan');
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function cek_login_admin()
    {
        $username = set_value('username');
        $password = set_value('password');

        $result = $this->db
            ->where('username', $username)
            ->where('password', md5($username))
            ->limit(1)
            ->get('admin');

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return FALSE;
        }
    }

    public function cek_login_karyawan()
    {
        $username = set_value('username');
        $password = set_value('password');

        $result = $this->db
            ->where('username', $username)
            ->where('password', md5($username))
            ->limit(1)
            ->get('karyawan');

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return FALSE;
        }
    }

    public function cek_login_pelanggan()
    {
        $username = set_value('username');
        $password = set_value('password');

        $result = $this->db
            ->where('username', $username)
            ->where('password', md5($username))
            ->limit(1)
            ->get('pelanggan');

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return FALSE;
        }
    }

    public function update_password($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function DownloadPembayaran($id)
    {
        $query = $this->db->get_where('pesanan', array('id_pesanan' => $id));
        return $query->row_array();
    }

    public function get_sum()
    {
        $this->db->select_sum('tarif', 'total');
        $this->db->from('layanan');
        return $this->db->get('')->row();
    }

    public function carikaryawan()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_karyawan', $keyword);
        $this->db->or_like('foto_karyawan', $keyword);
        return $this->db->get('karyawan')->result_array();
    }

    function getdatabyid($id_pembayaran)
    {
        $query = $this->db->query("SELECT * FROM pembayaran where id_pembayaran = '$id_pembayaran' ORDER BY id_pembayaran ASC");
        return $query->result();
    }
    public function pesanan_masuk()
    {
        $this->db->from('pesanan');
        $this->db->join('karyawan', 'karyawan.id_karyawan = pesanan.id_karyawan');
        $this->db->join('layanan', 'layanan.id_layanan = pesanan.id_layanan');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan = pesanan.id_pelanggan');
        $this->db->where('pesanan.status_pesanan = "Belum Selesai"');
        $this->db->order_by('id_pesanan', 'DESC');
        return $this->db->get();
    }

    public function pesanan_selesai()
    {
        $this->db->from('pesanan');
        $this->db->join('karyawan', 'karyawan.id_karyawan = pesanan.id_karyawan');
        $this->db->join('layanan', 'layanan.id_layanan = pesanan.id_layanan');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan = pesanan.id_pelanggan');
        $this->db->where('pesanan.status_pesanan = "Selesai"');
        $this->db->order_by('id_pesanan', 'DESC');
        return $this->db->get();
    }


    public function get_all_count()
    {
        $pelanggan = $this->db->get('pelanggan')->num_rows();
        $admin = $this->db->get('admin')->num_rows();
        $karyawan = $this->db->get('karyawan')->num_rows();
        $pesanan = $this->db->get('pesanan')->num_rows();
        $barbershop = $this->db->get('barbershop')->num_rows();
        $belum = $this->db->query("SELECT * FROM pesanan ps, karyawan ky  WHERE ps.status_pesanan= 'Belum Selesai' 
        AND ps.id_karyawan=ky.id_karyawan")->num_rows();
        $count = [
            'pelanggan' => $pelanggan,
            'admin' => $admin,
            'karyawan' => $karyawan,
            'pesanan' => $pesanan,
            'barbershop' => $barbershop,
            'belum' => $belum,
        ];
        return $count;
    }

    function getdata()
    {
        $query = $this->db->query("SELECT * FROM pembayaran ORDER BY id_pembayaran ASC");
        return $query->result();
    }

    public function total()
    {
        $karyawan = $this->session->userdata('id_karyawan');
        $pesanan = $this->db->query("SELECT * FROM pesanan ps, karyawan ky  WHERE ps.status_pesanan= 'Belum Selesai' AND ps.id_karyawan=ky.id_karyawan AND ky.id_karyawan=$karyawan")->num_rows();
        $selesai = $this->db->query("SELECT * FROM pesanan ps, karyawan ky  WHERE ps.status_pesanan= 'Selesai' AND ps.id_karyawan=ky.id_karyawan AND ky.id_karyawan=$karyawan")->num_rows(); 
        $semua = $this->db->query("SELECT * FROM pesanan ps, karyawan ky  WHERE ps.id_karyawan=ky.id_karyawan AND ky.id_karyawan=$karyawan")->num_rows();   
        $count = [
            'pesanan' => $pesanan,
            'selesai' => $selesai,
            'semua' => $semua,
        ];
        return $count;
    }

    function getdata_()
    {
        $query = $this->db->query("SELECT * FROM pembayaran ORDER BY id_pembayaran ASC");
        return $query->result();
    }

    function save($data)
  {
    $finish = $this->db->insert('pembayaran', $data);
    return $finish;
  }
    
}