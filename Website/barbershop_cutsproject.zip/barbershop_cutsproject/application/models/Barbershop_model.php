<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barbershop_model extends CI_Model
{
    function getdata()
    {
        $query = $this->db->query("SELECT * FROM barbershop ORDER BY id_barbershop ASC");
        return $query->result();
    }
    
    function save($data){
        $tambah = $this->db->insert('barbershop', $data);
        return $tambah;
    }
    function getdatabyid($id_barbershop)
    {
        $query = $this->db->query("SELECT * FROM barbershop where id_barbershop = '$id_barbershop' ORDER BY id_barbershop ASC");
        return $query->result();
    }

    function update($data, $kondisi)
    {
        $this->db->where($kondisi);
        $this->db->update('barbershop',$data);
        return true;
    }

    function checkProductImage($id_barbershop){  // untuk cek gambar
        $query = $this->db->get_where('barbershop', ['id_barbershop' => $id_barbershop]);
        return $query->row();
    }

    function delete($kondisi)
    {
        $this->db->where($kondisi);
        $this->db->delete('barbershop');
        return true;
    }
}