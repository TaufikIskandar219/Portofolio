<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order_model extends CI_Model
{
    function getdata()
    {
        $query = $this->db->query("SELECT * FROM pesanan ORDER BY id_pesanan ASC");
        return $query->result();
    }
    
    function save($data){
        $tambah = $this->db->insert('pesanan', $data);
        return $tambah;
    }
    function getdatabyid($id_pesanan)
    {
        $query = $this->db->query("SELECT * FROM pesanan where id_pesanan = '$id_pesanan' ORDER BY id_pesanan ASC");
        return $query->result();
    }

    function update($data, $kondisi)
    {
        $this->db->where($kondisi);
        $this->db->update('pesanan',$data);
        return true;
    }

    function getlayanan($tarif)
    {
        $query = $this->db->query("SELECT * FROM layanan where tarif = '$tarif' ORDER BY id_layanan ASC");
        return $query->result();
    }

    function delete($kondisi)
    {
        $this->db->where($kondisi);
        $this->db->delete('pesanan');
        return true;
    }

    public function pesanan_masuk()
    {
        $this->db->from('pesanan');
        $this->db->join('karyawan', 'karyawan.id_karyawan = pesanan.id_karyawan');
        $this->db->join('layanan', 'layanan.id_layanan = pesanan.id_layanan');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan = pesanan.id_pelanggan');
        $this->db->where('pesanan.status_pesanan = "Belum Selesai"');
        $this->db->order_by('id_pesanan', 'DESC');
        return $this->db->get();
    }
    public function pesanan_selesai()
    {
        $this->db->from('pesanan');
        $this->db->join('karyawan', 'karyawan.id_karyawan = pesanan.id_karyawan');
        $this->db->join('layanan', 'layanan.id_layanan = pesanan.id_layanan');
        $this->db->join('pelanggan', 'pelanggan.id_pelanggan = pesanan.id_pelanggan');
        $this->db->where('pesanan.status_pesanan = "Selesai"');
        $this->db->order_by('id_pesanan', 'DESC');
        return $this->db->get();
    }
    public function get_data($table){
        return $this->db->get($table);
    }

    public function jumlah()       
    {
        $ps['pesanan_masuk'] = $this->db->query("SELECT * FROM pesanan ps WHERE ps.status_pesanan = 'Belum Selesai'")->num_rows();
        $pesanan_masuk = $ps->num_rows();

    }
    

}